create
    definer = admin@`%` function get_map_id(p_map_name varchar(64)) returns int
BEGIN
	DECLARE ans INT;
    
	SELECT map_id INTO ans 
    FROM maps 
    WHERE map_name = p_map_name;
	RETURN ans;
END;

