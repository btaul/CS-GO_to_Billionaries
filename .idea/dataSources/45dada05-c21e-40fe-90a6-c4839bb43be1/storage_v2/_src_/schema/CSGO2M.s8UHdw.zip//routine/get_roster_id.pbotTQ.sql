create
    definer = admin@`%` function get_roster_id(p_team_name varchar(128), p_match_id int) returns int
BEGIN
	DECLARE ans INT;
    
    SELECT 
		roster_id
	INTO ans
    FROM rosters r
    JOIN teams t
		ON r.team_id = t.team_id
	WHERE team_name = p_team_name
		AND match_id = p_match_id;
    
	RETURN ans;
END;

