create
    definer = admin@`%` function get_team_id(p_team_name varchar(128)) returns int
BEGIN
	DECLARE ans INT;
    
    SELECT team_id INTO ans FROM teams WHERE team_name = p_team_name;
	RETURN ans;
END;

